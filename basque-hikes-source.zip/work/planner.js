/* Map visibility and the saved itinerary are independent visitor choices. */
const PLANNER=DATA.planner,baseRoutes=JSON.parse(JSON.stringify(routes));
const PLAN_KEY='basque-hikes-coastal12-v1';
const requestedInitialView=new URLSearchParams(location.search).get('view');
let plannerReady=false,planWriting=false,planTab='mapview',browseMode='recommended';
let viewedPlanKey='',planUndoState=null;
function validTripDate(s){if(!/^2026-(09|10|11)-\d{2}$/.test(s||''))return false;const d=new Date(s+'T12:00:00Z');return Number.isFinite(d.getTime())&&d.toISOString().slice(0,10)===s;}
function addDays(s,n){return new Date(Date.parse(s+'T12:00:00Z')+n*86400000).toISOString().slice(0,10);}
function niceDate(s){return s?new Date(s+'T12:00:00Z').toLocaleDateString('ru-RU',{day:'numeric',month:'long',weekday:'short',timeZone:'Europe/Madrid'}):'Дата пока не выбрана';}
function cleanIDs(ids,max=routes.length){return [...new Set(Array.isArray(ids)?ids.map(Number).filter(n=>Number.isInteger(n)&&routes.some(r=>r.id===n)):[])].slice(0,max);}
function normalizePlan(v={}){const days=Number(v.days)===1?1:2,itinerary=cleanIDs(v.itinerary);return {days,recommended:cleanIDs(v.recommended,2).join(',')===itinerary.join(',')?cleanIDs(v.recommended,2):[],date:validTripDate(v.date)?v.date:'',hours:0,exposure:['yes','no'].includes(v.exposure)?v.exposure:'any',transport:v.transport==='public'?'public':'car',itinerary,variants:Object.fromEntries(Object.entries(v.variants||{}).filter(([id,value])=>PLANNER.variants[id]?.[value])),starts:Object.fromEntries(Object.entries(v.starts||{}).filter(([id,t])=>routes.some(r=>r.id===Number(id))&&/^([01]\d|2[0-3]):[0-5]\d$/.test(t))),adults:Math.max(1,Math.min(12,Math.floor(+v.adults)||2)),compare:cleanIDs(v.compare),focus:cleanIDs([v.focus],1)[0]||null,browse:v.browse==='all'?'all':'recommended',region:['all','west','east','cortina','selected'].includes(v.region)?v.region:'all',effort:['all','gentle','medium','hard'].includes(v.effort)?v.effort:'all'};}
function readPlan(){
 const params=new URLSearchParams(location.search),shared=params.has('plan')||params.has('routes')||params.has('route');
 if(shared)return normalizePlan({days:params.get('days'),date:params.get('date'),hours:params.get('hours'),exposure:params.get('heights'),transport:params.get('transport'),recommended:(params.get('recommended')||'').split(','),itinerary:(params.get('plan')||'').split(','),compare:(params.has('routes')?params.get('routes'):(params.get('route')||params.get('plan')||'')).split(','),focus:params.get('route'),variants:Object.fromEntries((params.get('short')||'').split(',').filter(Boolean).map(id=>[id,'short'])),starts:Object.fromEntries((params.get('starts')||'').split(',').filter(x=>/^\d+@\d\d:\d\d$/.test(x)).map(x=>x.split('@'))),adults:params.get('adults'),browse:params.get('catalog')||'all',region:params.get('region'),effort:params.get('effort')});
 const routeID=Number(document.body.dataset.route);if(routeID)return normalizePlan({compare:[routeID],focus:routeID,browse:'all'});
 try{return normalizePlan(JSON.parse(localStorage.getItem(PLAN_KEY))||{});}catch{return normalizePlan();}
}
let trip=readPlan();
function configFor(id){const original=PLANNER.routes[id],v=PLANNER.variants[id]?.[trip.variants[id]];return {...original,...v};}
function routeDate(id){const i=trip.itinerary.indexOf(Number(id));return trip.date&&trip.itinerary.length<=trip.days?addDays(trip.date,Math.max(0,i)):'';}
function useDate(id){return routeDate(id)||trip.date||weatherDateKey();}
function applyVariants(){
 for(const r of routes){const base=baseRoutes.find(x=>x.id===r.id),v=PLANNER.variants[r.id]?.[trip.variants[r.id]];Object.keys(r).forEach(k=>delete r[k]);Object.assign(r,JSON.parse(JSON.stringify(base)),v||{});}
}
function relevantStops(r,type){const config=configFor(r.id);return stops.filter(s=>s.type===type&&s.routes.includes(r.id)&&(type!=='parking'||s.id===config.parking));}
function parkingFor(id){return stops.find(s=>s.id===configFor(id).parking);}
function planURL(){const url=new URL(location.protocol==='file:'?'https://visokihy-cyber.github.io/basque-hikes/':document.baseURI);url.search='';url.hash='';url.pathname=url.pathname.replace(/(?:index|route-\d{2})\.html$/,'');const p=url.searchParams;p.set('plan',trip.itinerary.join(','));p.set('routes',[...visible].join(','));p.set('days',trip.days);if(trip.recommended?.length)p.set('recommended',trip.recommended.join(','));p.set('view',trip.itinerary.length?'tripview':'mapview');if(trip.date)p.set('date',trip.date);p.set('hours',trip.hours);p.set('heights',trip.exposure);p.set('transport',trip.transport);p.set('adults',trip.adults);p.set('catalog',browseMode);p.set('region',browseRegion);p.set('effort',browseEffort);if(selected)p.set('route',selected);const short=Object.keys(trip.variants);if(short.length)p.set('short',short.join(','));const starts=Object.entries(trip.starts).map(([id,t])=>id+'@'+t);if(starts.length)p.set('starts',starts.join(','));return url;}
function savePlan(){if(!plannerReady||planWriting)return;trip.compare=[...visible];trip.focus=selected;trip.browse=browseMode;trip.region=browseRegion;trip.effort=browseEffort;try{let href=location.href;const params=new URLSearchParams(location.search);if(params.has('plan')||params.has('routes')||params.has('route')||document.body.dataset.route){const u=planURL();u.searchParams.set('view',planTab);if(+document.body.dataset.route===selected&&visible.size===1)u.pathname=location.pathname;href=u.href;}history.replaceState({trip:JSON.parse(JSON.stringify(trip)),tab:planTab},'',href);}catch{}try{localStorage.setItem(PLAN_KEY,JSON.stringify(trip));$('saveState').textContent='План сохраняется на этом устройстве';}catch{$('saveState').textContent='Автосохранение недоступно — скопируйте ссылку на план';}}
function toast(message){$('plannerToast').textContent=message;$('plannerToast').hidden=false;clearTimeout(toast.timer);toast.timer=setTimeout(()=>{$('plannerToast').hidden=true;},6500);}
async function sharePlan(){const url=planURL().href;try{await navigator.clipboard.writeText(url);toast('Ссылка на ваш план скопирована');}catch{$('shareText').value=url;$('shareDialog').showModal();$('shareText').select();}}
function routePermalink(id){return 'https://visokihy-cyber.github.io/basque-hikes/route-'+String(id).padStart(2,'0')+'.html'+(trip.variants[id]?'?route='+id+'&short='+id:'');}
function setVariant(id,value){if(trip.itinerary.includes(Number(id))&&(trip.variants[id]||'full')!==value)trip.recommended=[];trip.variants[id]=value;if(value==='full')delete trip.variants[id];applyVariants();document.querySelectorAll('[data-route-details][open]').forEach(d=>d.open=false);$('routeList').innerHTML='';if(selected===id){pause();activeTrack='';}drawList();drawMap();updateTrackSelect();fitVisible();refreshPlanner();toast(value==='short'?'Карта, характеристики и скачивание обновлены для короткого варианта':'Восстановлен полный вариант маршрута');}
function recommendedRoutes(){return routes.filter(r=>{const c=configFor(r.id);return trip.exposure!=='no'||!c.exposure&&!c.technical;});}
function catalogOrder(){return [...routes].sort((a,b)=>a.id-b.id);}

function updatePreferences(){
 trip.exposure=$('tripHeights').value;browseMode='recommended';browseRegion=$('browseArea').value;browseEffort=$('browseEffort').value;
 closeRouteDetail();$('routeList').innerHTML='';drawList();drawMap();renderDetail();fitVisible();refreshPlanner();
}

function routeTags(r){const c=configFor(r.id),tags=[c.technical?'Нужны навыки':c.exposure?'Обрывы или крутые склоны':'Без сложных оборудованных участков'];if(PLANNER.liftSchedules[r.id])tags.push('Нужен подъёмник');if(c.returnBus)tags.push('Обратно автобусом');if(c.internalTransfer)tags.push('Переезд внутри дня');if(trip.variants[r.id])tags.push('Короткий вариант');return '<div class="route-tags">'+tags.map((s,i)=>'<span class="'+(i===0&&(c.exposure||c.technical)?'caution':'')+'">'+esc(s)+'</span>').join('')+'</div>';}
function stopStatus(s,date){
 const d=date||weatherDateKey(),v=PLANNER.foodSchedules[s.id],day=new Date(d+'T12:00:00Z').getUTCDay();
 if(!v||v.unconfirmed)return {tone:'unknown',text:s.type==='food'?'Работу кухни нужно уточнить':'Доступ и наличие мест нужно уточнить'};
 if(v.from&&d<v.from||v.through&&d>v.through)return {tone:'unknown',text:'Нет подтверждённого графика на эту дату'};
 if(v.closedDays.includes(day))return {tone:'closed',text:'Выходной по опубликованному графику'};
 return {tone:'scheduled',text:'По расписанию '+v.hours+(v.kitchen?' · кухня '+v.kitchen:' · часы кухни уточните')};
}
function statusHTML(s,date){const state=stopStatus(s,date);return '<div class="availability '+state.tone+'"><b>'+esc(niceDate(date||weatherDateKey()))+'</b><span>'+esc(state.text)+'</span></div>';}
function liftInfo(id,date){const lift=PLANNER.liftSchedules[id];if(!lift)return null;const d=date||weatherDateKey();if(d<lift.from||d>lift.through)return {...lift,unavailable:true,close:null};return {...lift,close:lift.periods.find(p=>d<=p[0])?.[1]||null,unavailable:false};}
function shortReadiness(r){const d=useDate(r.id),lift=liftInfo(r.id,d),alerts=routeAlerts([r.id],d),issues=[];if(lift?.unavailable)issues.push('Дата вне опубликованного сезона подъёмника');else if(lift)issues.push('Подъёмник до '+lift.close);if(r.bookingRequired)issues.push('Нужна предварительная бронь');if(alerts.length)issues.push('Ограничения: '+alerts.length);return '<div class="route-readiness">'+issues.map(x=>'<span>'+esc(x)+'</span>').join('')+'</div>';}
function routeFoodHTML(r){const list=relevantStops(r,'food'),walking=list.filter(s=>s.access==='walking'),date=useDate(r.id),available=walking.filter(s=>stopStatus(s,date).tone==='scheduled'),primary=available[0];let intro=primary?'<p class="lunch-pick"><b>Остановка для обеда: '+esc(primary.name)+'.</b> '+esc(PLANNER.foodSchedules[primary.id]?.approach||primary.description)+' Планируйте прийти до окончания работы кухни; уточните стол у заведения.</p>':'<p class="lunch-pick"><b>Возьмите еду и воду с собой.</b> На этот день работа подходящей кухни на пешем маршруте не подтверждена. Остановку в хижине можно добавить после уточнения.</p>';if(r.foodNote)intro='<p class="lunch-pick">'+esc(r.foodNote)+'</p>';if(walking.length)intro+='<p class="muted">На тропе и в пешей близости</p>'+routeStopList(r,'food',walking);const driving=list.filter(s=>s.access!=='walking');if(driving.length)intro+='<h3>После прогулки · на машине</h3>'+routeStopList(r,'food',driving);return intro;}
function nearestPointDistance(a,b){return Math.hypot((a[0]-b[0])*111195,(a[1]-b[1])*76000);}
function distanceToSegment(p,a,b){const x=(b[1]-a[1])*76000,y=(b[0]-a[0])*111195,px=(p[1]-a[1])*76000,py=(p[0]-a[0])*111195,u=Math.max(0,Math.min(1,(px*x+py*y)/(x*x+y*y||1)));return Math.hypot(px-u*x,py-u*y);}
function roadTouches(point,path,limit=750){return path.some((p,i)=>i&&distanceToSegment(point,path[i-1],p)<limit);}
function alertTouches(a,ids){
 if(ids.some(id=>{const c=configFor(id);return nearestPointDistance(a.pos,parkingFor(id).pos)<1200||routeBy(id).tracks.some(tid=>roadTouches(a.pos,trackBy(tid).points,600));}))return true;
 const result=tripTransfers(ids);return result?.legs.some(l=>roadTouches(a.pos,legRoad(l),750))||false;
}
function dateIntersects(a,date){if(!date)return alertInWindow(a);return weatherDateKey(new Date(a.start))<=date&&(!a.end||(!a.end||weatherDateKey(new Date(Date.parse(a.end)-1))>=date));}
function routeAlerts(ids,date=''){return (DATA.alerts||[]).filter(a=>dateIntersects(a,date)&&alertTouches(a,ids));}
function alertsHTML(ids,date=''){const list=routeAlerts(ids,date);return list.length?'<div class="context-alerts">'+list.map(a=>'<details><summary><span class="alert-key">!</span> '+esc(a.name)+' · '+esc(a.title)+'</summary>'+alertPopup(a)+'<button data-alert-focus="'+esc(a.id)+'">Показать ограничение на карте</button></details>').join('')+'</div>':'';}
function tripTransfers(ids){return calculateTransfers(ids,DATA.driving);}
function minutes(t){const [h,m]=t.split(':').map(Number);return h*60+m;}
function clockText(n){return String(Math.floor(n/60)%24).padStart(2,'0')+':'+String(Math.round(n%60)).padStart(2,'0')+(n>=1440?' следующего дня':'');}
function dayTiming(id){const c=configFor(id),start=trip.starts[id]||c.suggestedStart,walk=c.hours,extra=c.extraMinutes,finish=[minutes(start)+walk[0]*60+extra,minutes(start)+walk[1]*60+extra],lift=liftInfo(id,useDate(id));return {start,finish,extra,late:!!lift?.close&&finish[1]>minutes(lift.close)-30,night:minutes(start)<7*60||finish[1]>(useDate(id).slice(5,7)==='09'?18*60:17*60),lift};}
function lodgeChoice(ids){const areas=[...new Set(ids.map(id=>routeBy(id).cluster))],key=areas.length===1?areas[0]:areas.includes('west')&&areas.includes('east')?'west-east':areas.includes('west')?'west-cortina':'cortina-east';return {...PLANNER.bases[key]};}
function knownCosts(ids){let tickets=0,car=0,unknown=[];for(const id of ids){tickets+=PLANNER.liftSchedules[id]?.perAdult||0;const park=parkingFor(id);if(trip.transport==='car'){if(Number.isFinite(park?.price))car+=park.price;else unknown.push(park?.name||'парковка');}}return {tickets,car,unknown};}
function returnBusHTML(id,date){const data=PLANNER.returnBus?.[id];return data?'<div class="return-bus"><b>Возвращение</b><p>'+esc(data.note)+'</p><a href="'+esc(data.source)+'" target="_blank" rel="noopener">Расписание ↗</a></div>':'';}
function fallbackHTML(id){return '<details class="plan-fallback"><summary>Запасной вариант</summary><p>'+esc(weatherConfig(id).avoid)+'</p><p>При грозе, сильном ветре, льду или плохой видимости перенесите горную прогулку. Рассмотрите музеи Бильбао, Сан-Себастьяна или Витории, а не другой открытый хребет.</p><a href="https://turismo.euskadi.eus/es/" target="_blank" rel="noopener">Идеи туристического портала Euskadi ↗</a></details>';}

function renderDay(id,index){const r=routeBy(id),c=configFor(id),date=routeDate(id),time=dayTiming(id),lift=time.lift,park=parkingFor(id),food=relevantStops(r,'food').filter(s=>s.access==='walking'),lunch=food.find(s=>stopStatus(s,useDate(id)).tone==='scheduled'),finish=time.finish.map(clockText).join('–'),alert=alertsHTML([id],date);return `<article class="plan-day" data-plan-day="${index}"><div class="plan-day-head"><div><span class="eyebrow">${trip.itinerary.length<=trip.days?'День '+(index+1):'Маршрут '+(index+1)} · ${esc(date?niceDate(date):trip.date?'День поездки не назначен':niceDate(date))}</span><h3><span class="num" style="--route:${r.color}">${id}</span>${esc(r.name)}</h3></div><button data-plan-remove="${index}" aria-label="Удалить из плана маршрут ${id}">×</button></div>${routeTags(r)}<p>${esc(r.distance)} · ${esc(r.time)} · набор ${esc(r.gain)}</p><label class="start-time">Плановый старт прогулки <input type="time" value="${time.start}" data-start="${id}"></label><p class="muted">Местное время Испании. Ниже ориентир для планирования с резервом ${time.extra} мин на отдых и местный транспорт; подъезд от места ночёвки в него не включён.</p>${time.night?'<p class="critical-note">Позднее окончание или ночной старт: перенесите прогулку на светлое время и проверьте время заката. В долинах темнеет раньше.</p>':''}${time.late?'<p class="critical-note">При таком старте можно не успеть к канатке. Начните раньше или выберите более короткую прогулку.</p>':''}${lift?.unavailable?'<p class="critical-note">Дата вне опубликованного сезона канатки. Этот план требует другого маршрута или подтверждённого способа подъёма.</p>':''}<ol class="day-steps">${arrivalStepHTML(r)}<li><b>${time.start} · прогулка</b><p>${esc(c.walk)}</p></li><li><b>Обед и отдых по пути</b><p>${lunch?esc(lunch.name)+'. '+esc(PLANNER.foodSchedules[lunch.id]?.kitchen?'Кухня '+PLANNER.foodSchedules[lunch.id].kitchen+'.':'Время кухни уточните заранее.'):'Возьмите еду и воду. Работа кухни на пешем маршруте на эту дату не подтверждена.'}</p></li><li><b>Ориентир окончания · ${finish}</b><p>${lift?'Канатка по опубликованному графику до '+esc(lift.close||'уточнения')+'. Приходите к верхней станции заранее. '+'':'Вернитесь до темноты. Плановое время не учитывает задержки из-за погоды, очередей или состояния тропы.'}</p>${lift?'<a href="'+esc(lift.source)+'" target="_blank" rel="noopener">Часы и билеты оператора ↗</a>':''}</li></ol>${returnBusHTML(id,useDate(id))}${alert}<div class="day-actions"><button data-plan-open="${id}">Карта и маршрут</button><button data-quick="season" data-id="${id}">Погода и условия</button><button data-quick="food" data-id="${id}">Лучшие рестораны</button><button data-quick="track" data-id="${id}">Скачать трек</button></div>${fallbackHTML(id)}</article>`;}
function arrivalStepHTML(r){
 if(trip.transport==='public')return '<li><b>До прогулки · общественный транспорт</b><p>'+esc(r.publicTransport||'Уточните остановку и рейсы к старту маршрута.')+'</p><a href="'+esc(r.publicTransportSource||'https://www.euskotren.eus/')+'" target="_blank" rel="noopener">Проверить рейсы туда и обратно ↗</a><p>Выберите обратный рейс заранее; время прогулки должно оставлять запас до его отправления.</p></li>';
 const park=parkingFor(r.id),note='Проверьте доступность места и местные правила парковки.';
 return '<li><b>До прогулки · подъезд на машине</b><p>'+esc(park.name)+'. '+note+'</p><a href="'+esc(hrefStart(r,''))+'" target="_blank" rel="noopener">До парковки в Google Maps ↗</a></li>';
}
function renderPlan(){
 if(planMapObserver){planMapObserver.disconnect();planMapObserver=null;}if(planOverviewMap){planOverviewMap.remove();planOverviewMap=null;}
 const ids=trip.itinerary,root=$('tripContent'),result=tripTransfers(ids),cost=knownCosts(ids),budgetOpen=!!root.querySelector('.budget[open]'),focusTarget=planFocusTarget();$('planDays').value=trip.days;$('planTransport').value=trip.transport;$('planSelectionHint').hidden=true;$('planOverview').hidden=!ids.length;$('planOverview').innerHTML=ids.length?planOverviewHTML(ids):'';$('downloadPlan').disabled=!ids.length;$('sharePlan').disabled=!ids.length;renderPlanUndo();$('planDate').value=trip.date;$('planDateLabel').textContent=trip.date?niceDate(trip.date)+(trip.days===2?' — '+niceDate(addDays(trip.date,1)):''):'Выберите дату поездки ниже';
 $('planSlots').innerHTML='';
 if(!trip.date)$('planDateLabel').textContent='Выберите даты поездки для проверки сезона и ограничений.';if(!ids.length){root.innerHTML=emptyPlanHTML();wirePlannerActions(root);return;}
 const lodge=lodgeChoice(ids);root.innerHTML=`${ids.length>1?planTransfersHTML(ids):''}<section class="plan-map-section"><h3>Вся поездка на карте</h3><div id="planMap" aria-label="Карта маршрутов плана"></div><p>${trip.transport==='public'?'Показаны пешие треки и точки. Автобусные линии не рассчитаны: выберите рейсы в разделе переездов.':'Пешие треки — цветные линии, переезды между ними — оранжевый пунктир.'}</p></section><section id="planWeather"><h3>Погода на даты поездки</h3>${ids.map(id=>'<div data-plan-weather="'+id+'"></div>').join('')}</section>${ids.map((id,i)=>'<article class="plan-full-route" data-plan-full="'+id+'"><div class="plan-day-head"><h2>№'+id+' · '+esc(routeBy(id).name)+'</h2><button data-plan-remove="'+i+'">Удалить из плана</button></div><p>'+esc(routeBy(id).intro)+'</p><label>Старт прогулки <input type="time" data-start="'+id+'" value="'+dayTiming(id).start+'"></label><p>'+esc(routeDate(id)?niceDate(routeDate(id)):'День пока не назначен')+'</p><div data-plan-body="'+id+'"></div></article>').join('')}<section class="lodging" id="planLodging"><div class="eyebrow">После выбора маршрутов</div><h3>Где удобно остановиться</h3><b>${esc(lodge.name)}</b><p>${esc(lodge.text)}</p><p class="muted">Рекомендация по географии выбранных треков. Сравните подъезд к обоим стартам и цену жилья; это не расчёт кратчайшего пути от отеля.</p><a href="https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(lodge.query)}" target="_blank" rel="noopener">Посмотреть район и жильё ↗</a> · <a href="${esc(lodge.source)}" target="_blank" rel="noopener">Туристический портал ↗</a></section><details class="budget"><summary>Расходы на транспорт и доступ</summary><label>Взрослых <input type="number" id="planAdults" min="1" max="12" value="${trip.adults}"></label><p>Подъёмники и местный автобус: <b>€${cost.tickets} на взрослого · €${cost.tickets*trip.adults} на группу</b>.</p>${trip.transport==='car'?`<p>Известные сборы за автомобиль: <b>€${cost.car}</b>. ${cost.unknown.length?'Дополнительно уточните: '+esc(cost.unknown.join('; '))+'.':''}</p>`:''}<p class="muted">Частичный бюджет по опубликованным тарифам 2026. Питание, жильё, топливо, внешние автобусы и неуказанные парковки добавляются отдельно. Для детей и льготных билетов смотрите условия операторов.</p><button data-plan-lifts>Билеты и скидки</button></details><section id="planTickets"></section><div class="plan-footer"><p>Проверьте прогноз, дорожный доступ, обратный транспорт и работу кухни перед выходом. Сохранённый план фиксирует сведения на момент скачивания.</p><button data-plan-download>Скачать план HTML</button><button data-plan-print>Печать / PDF</button></div>`;
 if(planTab==='tripview'){renderPlanTickets();root.querySelectorAll('[data-plan-body]').forEach(el=>renderRouteBody(+el.dataset.planBody,el,true));root.querySelectorAll('[data-plan-weather]').forEach(el=>loadPlanWeather(el));requestAnimationFrame(()=>{if(planTab==='tripview'&&$('planMap'))renderPlanMap();});}
 wirePlannerActions(root);if(root.querySelector('.budget'))root.querySelector('.budget').open=budgetOpen;if(focusTarget)document.querySelector(focusTarget)?.focus({preventScroll:true});$('planAdults')?.addEventListener('change',e=>{trip.adults=Math.max(1,Math.min(12,Math.floor(+e.target.value)||1));refreshPlanner();});
}
function refreshPlanner(){
 if(!plannerReady)return;
 renderPlan();savePlan();renderPlanDock();renderTransitTickets();
 $('mapTripDate').textContent=trip.date?'· Поездка: '+niceDate(trip.date):'';
 document.querySelectorAll('[data-card]').forEach(card=>{const id=+card.dataset.card,notes=card.querySelector('.route-readiness');if(notes)notes.outerHTML=shortReadiness(routeBy(id));});
 renderMapQuick();
 document.querySelectorAll('[data-add-plan]').forEach(b=>{const index=trip.itinerary.indexOf(+b.dataset.addPlan);b.textContent=index>=0?'Убрать':'+ Добавить в план';b.classList.toggle('in-plan',index>=0);});
}

function addToPlan(id){
 id=Number(id);if(!routeBy(id))return;
 if(trip.itinerary.includes(id)){removePlanDay(trip.itinerary.indexOf(id));return;}
 planUndoState=null;trip.recommended=[];trip.itinerary.push(id);refreshPlanner();drawAlerts();
 toast('Маршрут добавлен. Сводка и переезды — в «Мой план».');
}

function openRouteSection(id,section){openRouteDetail(id,section,true);}
function wirePlannerActions(root){root.querySelectorAll('[data-add-plan]').forEach(b=>b.onclick=()=>addToPlan(+b.dataset.addPlan));root.querySelectorAll('[data-open-plan]').forEach(b=>b.onclick=openMyPlan);root.querySelectorAll('[data-quick]').forEach(b=>b.onclick=()=>openRouteSection(+b.dataset.id,b.dataset.quick));root.querySelectorAll('[data-repick]').forEach(b=>b.onclick=()=>{setTab('mapview');$('tripFinder').scrollIntoView({block:'start'});$('browseArea').focus({preventScroll:true});});root.querySelectorAll('[data-plan-remove]').forEach(b=>b.onclick=()=>removePlanDay(+b.dataset.planRemove));root.querySelectorAll('[data-plan-open]').forEach(b=>b.onclick=()=>{setTab('mapview');selectRoute(+b.dataset.planOpen,true);});root.querySelectorAll('[data-start]').forEach(el=>el.onchange=()=>{trip.starts[el.dataset.start]=el.value||'09:00';refreshPlanner();});root.querySelectorAll('[data-plan-move]').forEach(b=>b.onclick=()=>movePlanRoute(+b.dataset.planMove,+b.dataset.delta));root.querySelectorAll('[data-plan-reverse]').forEach(b=>b.onclick=()=>{trip.recommended=[];trip.itinerary.reverse();refreshPlanner();drawAlerts();});root.querySelectorAll('[data-plan-map]').forEach(b=>b.onclick=()=>{$('planMap')?.scrollIntoView({block:'center',behavior:'smooth'});});root.querySelectorAll('[data-fallback]').forEach(b=>b.onclick=()=>{const id=+b.dataset.fallback;if(id===2)setVariant(2,'short');openRouteSection(id,'season');});root.querySelectorAll('[data-plan-lifts]').forEach(b=>b.onclick=()=>setTab('liftview'));root.querySelectorAll('[data-plan-download]').forEach(b=>b.onclick=downloadPlan);root.querySelectorAll('[data-plan-print]').forEach(b=>b.onclick=()=>window.print());root.querySelectorAll('[data-alert-focus]').forEach(b=>b.onclick=()=>{setTab('mapview');const a=DATA.alerts.find(x=>x.id===b.dataset.alertFocus);showAllRoutes=true;drawMap();map.setView(a.pos,13);alertMarkers[a.id]?.openPopup();});}
function downloadPlan(){const copy=$('tripContent').cloneNode(true);copy.querySelectorAll('button img').forEach(img=>img.parentElement.replaceWith(img));copy.querySelectorAll('img').forEach(img=>{img.src=new URL(img.getAttribute('src'),document.baseURI).href;img.loading='eager';});copy.querySelectorAll('button,input').forEach(e=>e.remove());copy.querySelector('#planMap')?.replaceWith(Object.assign(document.createElement('p'),{innerHTML:'<a href="'+esc(planURL().href)+'">Открыть интерактивную карту поездки на сайте ↗</a>'}));copy.querySelectorAll('details').forEach(e=>e.open=true);const css='img{max-width:100%;height:auto}svg{width:100%;height:160px}figure{margin:15px 0}.plan-photo-grid{display:grid;grid-template-columns:1fr 1fr;gap:15px}body{max-width:850px;margin:30px auto;padding:0 20px;font:16px/1.6 system-ui;color:#173544}article,section,details{margin:20px 0;padding:18px;border:1px solid #ccd9df;border-radius:12px}a{color:#176178}h3{font-size:22px}.day-steps li{padding:8px 0}.critical-note{background:#fff1de;padding:12px}.route-tags{font-size:13px}.route-tags span{margin-right:10px}.overview-metrics{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}.overview-metrics b,.overview-metrics span{display:block}.overview-metrics span{font-size:12px}.overview-route,.overview-lodging,.overview-note{font-size:14px}@media(max-width:480px){.overview-metrics{grid-template-columns:1fr}}';const html='<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Мой план · Страна Басков</title><style>'+css+'</style><h1>Мои выходные в Стране Басков</h1><p>'+esc($('planDateLabel').textContent)+'</p>'+$('planOverview').outerHTML+copy.innerHTML+'<p>Сохранено '+esc(new Date().toLocaleString('ru-RU'))+'. Расписания и ограничения требуют повторной проверки.</p><p><a href="'+esc(planURL().href)+'">Открыть этот план на сайте</a></p></html>';saveBlob(html,'basque-hikes-my-plan.html','text/html');}
function saveBlob(body,name,type){const u=URL.createObjectURL(new Blob([body],{type})),a=document.createElement('a');a.href=u;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),60000);}
async function ensureOffline(){if(OFF.areas.length)return true;try{$('maperror').hidden=false;$('maperror').textContent='Загружаем карту района… Для использования без сети доступен полный архив в разделе подготовки.';const response=await fetch(new URL('offline.json',document.baseURI));if(!response.ok)throw new Error();const value=await response.json();if(!value.areas?.length||!value.roads?.length)throw new Error();OFF=value;offIndex.clear();OFF.areas.forEach((f,i)=>offAdd('a',i,f[2]));OFF.roads.forEach((f,i)=>offAdd('r',i,f[2]));OFF.labels.forEach((p,i)=>offAdd('l',i,[p[1],p[2],p[1],p[2]]));$('maperror').hidden=true;return true;}catch{$('maperror').hidden=false;$('maperror').textContent='Не удалось загрузить карту района. Попробуйте при подключении к сети или откройте заранее скачанный полный архив.';return false;}}
function initPlanner(){
 if(!trip.itinerary.includes(1)&&!trip.focus&&!trip.compare.length&&trip.hours>0&&trip.hours<=5&&trip.exposure==='no')trip.variants[1]='short';if(trip.hours>0&&trip.hours<=2&&!trip.itinerary.includes(2))trip.variants[2]='short';applyVariants();browseMode=trip.browse;browseRegion=trip.region;browseEffort=trip.effort;visible=new Set(trip.compare);selected=visible.has(trip.focus)?trip.focus:null;showAllRoutes=!visible.size;if(selected)$('routePicker').value=selected;
 $('tripHeights').value=trip.exposure;
 $('planDate').onchange=()=>{if(!$('planDate').reportValidity()){$('planDate').value=trip.date;toast('Выберите дату осени 2026 года');return;}trip.date=validTripDate($('planDate').value)?$('planDate').value:'';document.querySelectorAll('[data-route-details][open]').forEach(d=>{d.open=false;d.querySelector('.route-card-body').innerHTML='';});refreshPlanner();drawAlerts();};['tripHeights','browseArea','browseEffort'].forEach(id=>$(id).onchange=()=>{setTab('mapview');updatePreferences();});$('resetFilters').onclick=resetHoliday;$('recommendDay').onclick=addRecommendedDay;$('sharePlan').onclick=sharePlan;$('shareClose').onclick=()=>$('shareDialog').close();$('downloadPlan').onclick=downloadPlan;
 $('planSlots').addEventListener('change',e=>{const input=e.target.closest('[data-plan-slot]');if(input)setPlanDay(+input.dataset.planSlot,+input.value);});
 $('mapQuick').addEventListener('click',e=>{const b=e.target.closest('[data-map-quick]');if(!b||!selected)return;openRouteSection(selected,b.dataset.mapQuick);});
 $('backToCatalog').onclick=returnToCatalog;$('detailAddPlan').onclick=()=>{if(detailRoute)addToPlan(detailRoute);};
 $('basemap').onchange=async()=>{const wanted=$('basemap').value;if(wanted==='offline'&&!await ensureOffline())return;if($('basemap').value!==wanted)return;tileSuccess=0;tileErrors=0;[osm,topo,offline].forEach(l=>map.removeLayer(l));$('maperror').hidden=true;({offline,osm,topo}[wanted]).addTo(map);drawBackgroundLabels();};
 $('planDays').onchange=()=>changePlanDays(+$('planDays').value);$('planTransport').onchange=()=>{trip.transport=$('planTransport').value;refreshPlanner();drawMap();};
 new ResizeObserver(()=>{document.body.style.setProperty('--plan-dock-height',$('planMini').offsetHeight+'px');}).observe($('planMini'));
 const resizeTop=()=>{document.body.style.setProperty('--header-height',document.querySelector('header').offsetHeight+'px');document.body.style.setProperty('--settings-height',$('mapSettings').offsetHeight+'px');};
 const topObserver=new ResizeObserver(resizeTop);topObserver.observe(document.querySelector('header'));topObserver.observe($('mapSettings'));resizeTop();
 const opening=selected;plannerReady=true;refreshPlanner();if(opening)openRouteDetail(opening,"",false);
 window.addEventListener('popstate',e=>{closeRouteDetail();planWriting=true;trip=e.state?.trip?normalizePlan(e.state.trip):readPlan();applyVariants();visible=new Set(trip.compare);selected=visible.has(trip.focus)?trip.focus:null;showAllRoutes=!visible.size;browseMode=trip.browse;browseRegion=trip.region;browseEffort=trip.effort;$('tripHeights').value=trip.exposure;$('routeList').innerHTML='';drawList();drawMap();renderDetail();fitVisible();setTab(e.state?.tab||new URLSearchParams(location.search).get('view')||'mapview',false);planWriting=false;refreshPlanner();});
}


function sameRouteSet(a,b){return a.length===b.length&&a.every(id=>b.includes(id));}
function renderMapQuick(){
 const id=detailRoute;$('mapQuick').hidden=!id;$('mapQuickTitle').textContent=id?'№'+id+' · '+routeBy(id).name:'';
 if(id){$('detailAddPlan').textContent=trip.itinerary.includes(id)?'Убрать':'Добавить в план';$('detailAddPlan').classList.toggle('in-plan',trip.itinerary.includes(id));}
}
function planIdentity(){return JSON.stringify([trip.itinerary,trip.variants,trip.date,trip.starts,trip.days]);}
function renderPlanDock(){
 if(!plannerReady)return;$('planMini').hidden=true;document.body.classList.remove('has-plan-dock');
 const nav=document.querySelector('header [data-tab="tripview"]'),pending=false,unseen=trip.itinerary.length&&viewedPlanKey!==planIdentity();
 nav.classList.toggle('plan-ready',planTab!=='tripview'&&!!(pending||unseen));
 nav.title='Маршрутов в плане: '+trip.itinerary.length+'. '+(trip.itinerary.length?'Открыть сводку поездки: дни, переезды и ночёвка':'Добавьте маршрут кнопкой «В план»');
 nav.setAttribute('aria-label','Мой план. Маршрутов: '+trip.itinerary.length);
 $('planBadge').textContent=String(trip.itinerary.length);
}
function openMyPlan(){setTab('tripview');}
function goToPicker(){returnToCatalog();}
function tripOverview(ids){
 const walk=ids.flatMap(id=>routeBy(id).tracks.map(trackBy)).filter(t=>t&&!['car','lift'].includes(t.mode));
 return {km:walk.reduce((sum,t)=>sum+t.km,0),hours:[0,1].map(i=>ids.reduce((sum,id)=>sum+configFor(id).hours[i],0)),drive:tripTransfers(ids)};
}
function basePlanHTML(ids){if(trip.transport!=='car')return '';return '<details class="info-section"><summary>Подъезды из Сан-Себастьяна<small>Отдельная поездка к каждому маршруту и обратно</small></summary>'+ids.map(id=>'<h4>'+esc(routeBy(id).name)+'</h4>'+baseArrivalHTML(id)).join('')+'</details>';}
function planOverviewHTML(ids){
 const t=tripOverview(ids),lodge=lodgeChoice(ids),fmt=n=>Number(n.toFixed(1)).toLocaleString('ru-RU'),pub=trip.transport==='public',drive=ids.length>1&&!pub?t.drive.seconds:0,total=t.hours.map(h=>h+drive/3600),heavy=total[1]>trip.days*8;
 return recommendationNote(ids)+'<h3>Ваша поездка — кратко</h3><div class="overview-metrics"><div><b>≈ '+fmt(t.km)+' км</b><span>пешком по линиям карты</span></div><div><b>'+t.hours.map(fmt).join('–')+' ч</b><span>треккинг · все '+ids.length+' маршрута</span></div><div><b>'+(ids.length<2?'Нет переездов':pub?'По расписанию':driveTime(drive))+'</b><span>'+(pub?'автобусы / поезда: время пока не рассчитано':'на машине между треками')+'</span></div></div><p><b>Всего: '+total.map(fmt).join('–')+' ч'+(pub&&ids.length>1?' + общественный транспорт':' с переездами')+'</b> на '+trip.days+' '+(trip.days===1?'день':'дня')+'.</p>'+(heavy?'<p class="critical-note">Это может быть слишком большой нагрузкой для '+trip.days+' '+(trip.days===1?'дня':'дней')+'. Сократите прогулки или добавьте время на поездку.</p>':'')+(pub&&ids.length>1?'<p class="overview-note">Автобусные переезды и ожидание пересадок не включены в итог: выберите рейсы по ссылкам ниже. Автомобильное время здесь не используется.</p>':'')+'<p class="overview-route">'+ids.map(id=>'№'+id+' · '+esc(routeBy(id).name)).join('<br>')+'</p>'+(ids.length>trip.days?'<p>Маршруты перечислены в порядке посещения; распределение по дням не задано. Время старта каждой прогулки ниже — отдельный ориентир.</p>':'')+basePlanHTML(ids)+'<p class="overview-lodging">База поездки: <a href="#planLodging">'+esc(lodge.name)+'</a></p><p class="overview-note">Подъезд от жилья, отдых, очереди и обратная дорога в сумму не входят.</p>';
}

function emptyPlanHTML(){return '<div class="plan-empty"><h3>Ваш план пока пуст</h3><p>Галочки показывают треки на карте. Чтобы включить маршрут в поездку и расчёт времени, нажмите «Добавить в план» на его карточке.</p><button class="primary-link" data-repick>Вернуться к маршрутам →</button></div>';}

function rememberPlanChange(message){planUndoState={message,trip:JSON.parse(JSON.stringify({...trip,compare:[...visible],focus:selected,browse:browseMode,region:browseRegion,effort:browseEffort}))};}
function planUndoHTML(){return planUndoState?'<span>'+esc(planUndoState.message)+'</span><button data-undo-plan>Вернуть</button>':'';}
function renderPlanUndo(){$('planUndo').innerHTML=planUndoHTML();$('planUndo').querySelector('[data-undo-plan]')?.addEventListener('click',restorePlanChange);}
function restorePlanChange(){
 if(!planUndoState)return;trip=normalizePlan(planUndoState.trip);planUndoState=null;applyVariants();
 visible=new Set(trip.compare);selected=visible.has(trip.focus)?trip.focus:null;showAllRoutes=!visible.size;
 browseMode=trip.browse;browseRegion=trip.region;browseEffort=trip.effort;
 $('tripHeights').value=trip.exposure;
 $('routeList').innerHTML='';drawList();drawMap();renderDetail();fitVisible();refreshPlanner();toast('Предыдущее состояние плана восстановлено');
}
function changePlanDays(days){
 trimPlanDays(days);setRouteSelection(visible);
}
function trimPlanDays(days){trip.days=Number(days)===1?1:2;}

function reconcileRouteSelection(ids){return new Set(cleanIDs([...ids]));}

function previewRouteSelection(id){return new Set([...visible,id]);}

function removePlanDay(index){
 if(!trip.itinerary[index])return;rememberPlanChange('Маршрут удалён из плана');trip.recommended=[];trip.itinerary.splice(index,1);refreshPlanner();drawAlerts();
}

function setPlanDay(index,id){
 if(id&&trip.itinerary.includes(id)&&trip.itinerary[index]!==id){toast('Этот маршрут уже в плане');renderPlan();return;}
 rememberPlanChange('Изменён маршрут в плане');if(trip.itinerary[index]!==id)trip.recommended=[];if(!id)trip.itinerary.splice(index,1);else if(index>=trip.itinerary.length)trip.itinerary.push(id);else trip.itinerary[index]=id;refreshPlanner();drawAlerts();
}

function planFocusTarget(){
 const e=document.activeElement;if(!e)return '';
 if(e.id==='planAdults')return '#planAdults';
 if(e.dataset.start)return '[data-start="'+e.dataset.start+'"]';
 if(e.dataset.planSlot!==undefined)return '[data-plan-slot="'+e.dataset.planSlot+'"]';
 return '';
}

// Catalog and reader are separate views of the same checked routes.
let detailRoute=null;
function filtersActive(){return !!(trip.exposure==='no'||browseRegion!=='all'||browseEffort!=='all');}
function mapRouteIDs(){const eligible=routes.filter(routeMatches).map(r=>r.id);return eligible;}
function closeRouteDetail(){
 detailRoute=null;pinnedStop='';pause();selected=null;activeTrack='';map.closePopup();$('profileStorage').append($('mapExtras'));$('detail').replaceChildren();$('detail').hidden=true;$('mapQuick').hidden=true;$('routeChooser').hidden=false;
 updateTrackSelect();
}
function returnToCatalog(){closeRouteDetail();setTab('mapview');drawList();drawMap();refreshPlanner();fitVisible();document.querySelector('.sidebar-scroll').scrollTop=0;if(innerWidth<721)document.querySelector('.sidebar').scrollIntoView({block:'start'});}
function resetHoliday(){
 closeRouteDetail();trip=normalizePlan({});trip.browse='recommended';browseMode='recommended';browseRegion='all';browseEffort='all';visible=new Set();selected=null;hiddenTracks.clear();planUndoState=null;transferOrder=[];transferKey='';applyVariants();
 $('tripHeights').value='any';$('browseArea').value='all';$('browseEffort').value='all';$('routeList').replaceChildren();returnToCatalog();window.scrollTo({top:0,behavior:'auto'});toast('Фильтры, выбранные маршруты и план сброшены');
}
function openRouteDetail(id,section='',zoom=true){
 if(!routeBy(id))return;setTab('mapview');pause();map.closePopup();
 if(!routeMatches(routeBy(id))){trip.exposure='any';browseMode='recommended';browseRegion='all';browseEffort='all';$('tripHeights').value='any';}
 const changed=detailRoute!==id;detailRoute=id;selected=id;visible.add(id);selectionTouched=true;$('routePicker').value=id;
 $('routeChooser').hidden=true;$('detail').hidden=false;
 if(changed||!$('detail').children.length){renderRouteBody(id,$('detail'));document.querySelector('.sidebar-scroll').scrollTop=0;}
 drawList();drawMap();if(changed||!activeTrack)chooseTrack(routeBy(id).tracks.find(t=>!hiddenTracks.has(t)&&!['car','lift'].includes(trackBy(t).mode)));refreshPlanner();renderProfile();$('mapQuick').querySelectorAll('[data-map-quick]').forEach(b=>b.classList.toggle('active',b.dataset.mapQuick===section));
 if(zoom)fitVisible();document.body.style.setProperty('--reader-tools-height',$('mapQuick').offsetHeight+'px');if(changed&&!section&&innerWidth<721)$('mapQuick').scrollIntoView({block:'start'});
 if(section){const target=$('detail').querySelector('[data-section="'+section+'"]');if(target){if(target.tagName==='DETAILS')target.open=true;requestAnimationFrame(()=>{const pane=document.querySelector('.sidebar-scroll');pane.scrollTop+=target.getBoundingClientRect().top-pane.getBoundingClientRect().top-$('mapQuick').offsetHeight-8;if(innerWidth<721)target.scrollIntoView({block:'start'});});}}
}
function removeDetailRoute(){const index=trip.itinerary.indexOf(detailRoute);if(index<0)return;removePlanDay(index);toast('Удалён из плана. Отображение на карте не изменено');}

function planTransfersHTML(ids){
 const result=tripTransfers(ids),pub=trip.transport==='public';
 return '<section class="plan-transfer"><h3>Переезды по порядку маршрутов</h3><p>Меняйте порядок стрелками: пересчитаются переезды, карта и последовательность описаний.</p><ol class="plan-order">'+ids.map((id,i)=>'<li><b>№'+id+' · '+esc(routeBy(id).name)+'</b><span><button data-plan-move="'+i+'" data-delta="-1" '+(!i?'disabled':'')+' aria-label="Переместить маршрут '+id+' раньше">↑</button><button data-plan-move="'+i+'" data-delta="1" '+(i===ids.length-1?'disabled':'')+' aria-label="Переместить маршрут '+id+' позже">↓</button></span></li>').join('')+'</ol>'+result.legs.map(l=>'<p><b>№'+l.from+' → №'+l.to+' · '+(pub?'Общественный транспорт: выбрать рейсы':'≈ '+driveKm(l.meters)+' · '+driveTime(l.seconds))+'</b><br><a href="'+legGoogle(l)+'" target="_blank" rel="noopener">'+(pub?'Найти автобусы / поезда':'Проверить дорогу')+' в Google Maps ↗</a></p>').join('')+(pub?'<p>Время зависит от даты, рейса и пересадок. Ожидание, переходы и отсутствие сезонных рейсов проверяйте в расписании. Дороги для автомобиля не являются схемой автобусов.</p><a href="https://www.euskotren.eus/" target="_blank" rel="noopener">Euskotren ↗</a> · <a href="https://www.euskotren.eus/es/autobus/lurraldebus" target="_blank" rel="noopener">Lurraldebus ↗</a>':'<p>Без пробок и остановок. Внутренние переезды маршрута и возвращение к первому старту считаются отдельно.</p>')+'<div><button data-plan-reverse>Обратить порядок</button><button data-plan-map>Показать на карте</button></div></section>';
}
function renderTransitTickets(){const el=$('transitTickets');if(el)el.hidden=trip.transport!=='public';}

// Map exploration never changes the itinerary or hides neighbouring routes.
let planEntryApproved=false,planOverviewMap=null,planMapObserver=null;
function pendingPlanIDs(){return [...visible].filter(id=>!trip.itinerary.includes(id));}
function askPlanSelection(){
 let dialog=$('planSelectionDialog');if(!dialog){dialog=document.createElement('dialog');dialog.id='planSelectionDialog';dialog.className='plan-selection-dialog';document.body.append(dialog);}
 const ids=pendingPlanIDs();dialog.innerHTML='<h2>Добавить отмеченные маршруты в поездку?</h2><p>На карте отмечены маршруты, которых ещё нет в плане:</p><ul>'+ids.map(id=>'<li>№'+id+' · '+esc(routeBy(id).name)+'</li>').join('')+'</ul><div class="dialog-actions"><button data-accept class="primary-link">Добавить все и открыть план</button><button data-keep>Оставить план как есть</button><button data-cancel>Вернуться к карте</button></div>';
 const enter=add=>{if(add){if(pendingPlanIDs().length)trip.recommended=[];trip.itinerary=cleanIDs([...trip.itinerary,...pendingPlanIDs()]);}dialog.close();planEntryApproved=true;try{setTab('tripview');}finally{planEntryApproved=false;}};
 dialog.querySelector('[data-accept]').onclick=()=>enter(true);dialog.querySelector('[data-keep]').onclick=()=>enter(false);dialog.querySelector('[data-cancel]').onclick=()=>dialog.close();dialog.showModal();
}
function toggleMapRoute(id){
 const ids=new Set(visible);ids.has(id)?ids.delete(id):ids.add(id);closeRouteDetail();visible=ids;selected=ids.has(id)?id:null;selectionTouched=true;
 drawList();drawMap();refreshPlanner();fitMapScope(id);
 requestAnimationFrame(()=>{const card=document.querySelector('[data-card="'+id+'"]'),pane=document.querySelector('.sidebar-scroll');if(!card)return;const a=card.getBoundingClientRect(),b=pane.getBoundingClientRect();if(innerWidth>720)pane.scrollTop+=a.top-b.top-Math.max(8,(pane.clientHeight-a.height)/2);else card.scrollIntoView({block:'center',behavior:'smooth'});card.classList.remove('map-picked');void card.offsetWidth;card.classList.add('map-picked');});
}
function movePlanRoute(index,delta){const next=index+delta;if(next<0||next>=trip.itinerary.length)return;trip.recommended=[];[trip.itinerary[index],trip.itinerary[next]]=[trip.itinerary[next],trip.itinerary[index]];refreshPlanner();drawAlerts();}
function renderPlanTickets(){const host=$('planTickets'),copy=$('liftview').cloneNode(true);copy.hidden=false;copy.querySelector('#transitTickets').hidden=trip.transport!=='public';copy.removeAttribute('id');copy.querySelectorAll('[id]').forEach(el=>el.id='plan-copy-'+el.id);host.replaceChildren(copy);}
function planPhoto(id){const p=photoBy(id);if(!p)return;pause();photoDialogIds=trackPhotos(p.tracks.includes(activeTrack)?activeTrack:p.tracks[0]).map(x=>x.id);if(!photoDialogIds.includes(id))photoDialogIds.unshift(id);photoDialogIndex=photoDialogIds.indexOf(id);photoReturnFocus=document.activeElement;renderPhotoDialog();if(!$('photoDialog').open)$('photoDialog').showModal();}
function mapAlertRelevant(a,ids,roadIDs,roadsShown=true){
 if(a.scope==='road')return roadsShown&&trip.transport==='car'&&roadIDs.length>1&&(tripTransfers(roadIDs)?.legs||[]).some(l=>roadTouches(a.pos,legRoad(l),500));
 return alertTouches(a,ids);
}
function routePhotosHTML(id){
 const r=routeBy(id),keys=[...r.points,...stops.filter(s=>s.routes.includes(id)).map(s=>'stop:'+s.id)];
 return '<div class="plan-point-photos">'+keys.map(key=>{const list=pointPhotos(key);if(!list.length)return '';const name=pois[key]?.name||stops.find(s=>'stop:'+s.id===key)?.name||key;return '<section><h3>'+esc(name)+'</h3><div class="plan-photo-grid">'+list.map(p=>'<figure><button data-plan-photo="'+p.id+'" aria-label="Открыть фото: '+esc(p.title)+'"><img loading="lazy" src="'+p.src+'" alt="'+esc(p.title)+'"></button><figcaption>'+esc(p.caption||p.title)+'<small>'+photoCredit(p)+'</small></figcaption></figure>').join('')+'</div></section>';}).join('')+'</div>';
}
function planProfileHTML(id){
 return '<details class="info-section plan-profiles" data-section="profile"><summary>Профиль и прохождение<small>Дистанция, набор и сброс высоты</small></summary>'+routeBy(id).tracks.map(trackBy).filter(t=>!['car','lift'].includes(t.mode)).map(t=>{const v=t.elevation?.values;if(!v?.length)return '<p>Для '+esc(t.name)+' профиль недоступен.</p>';const lo=Math.min(...v),hi=Math.max(...v),totals=elevationTotals(v),path=v.map((z,i)=>(i?'L':'M')+(10+i/(v.length-1)*780).toFixed(1)+','+(140-(z-lo)/(hi-lo||1)*125).toFixed(1)).join(' ');return '<h3>'+esc(t.name)+'</h3><p>'+t.km.toFixed(1)+' км · ↑ ≈ '+Math.round(totals.gain)+' м · ↓ ≈ '+Math.round(totals.loss)+' м</p><svg viewBox="0 0 800 155" role="img" aria-label="Профиль высот '+esc(t.name)+'"><path d="'+path+'" fill="none" stroke="'+routeBy(id).color+'" stroke-width="3" vector-effect="non-scaling-stroke"/></svg><p class="muted">Высоты ≈ '+Math.round(lo)+'–'+Math.round(hi)+' м. Цифровая модель высот: приблизительная поверхность рельефа'+(t.mode==='tunnel'?', не высота пути внутри тоннеля':'')+'.</p>';}).join('')+'</details>';
}
function renderPlanMap(){
 if(planOverviewMap||!trip.itinerary.length||!$('planMap'))return;
 const ids=[...trip.itinerary],m=planOverviewMap=L.map('planMap',{scrollWheelZoom:false}),bounds=[];addMapFullscreen(m,$('planMap'));
 const grid=new OfflineGrid({tileSize:256,minZoom:7,maxZoom:19,attribution:'© OpenStreetMap contributors · ODbL',updateWhenIdle:true});
 const street=L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap contributors'});
 const top=L.tileLayer('https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png',{maxZoom:17,attribution:'© OpenStreetMap contributors · OpenTopoMap (CC-BY-SA)'});if(OFF.areas.length&&($('basemap').value==='offline'||!navigator.onLine))grid.addTo(m);else if($('basemap').value==='topo')top.addTo(m);else street.addTo(m);L.control.layers({'OpenStreetMap':street,'OpenTopoMap':top,'Офлайн · Страна Басков':grid},null,{collapsed:false}).addTo(m);m.on('baselayerchange',async e=>{if(e.layer===grid&&await ensureOffline())grid.redraw();});
 ids.forEach(id=>{const r=routeBy(id);r.tracks.map(trackBy).forEach(t=>{bounds.push(...t.points);L.polyline(t.points,{color:'#fff',weight:8,interactive:false}).addTo(m);L.polyline(t.points,{color:r.color,weight:4,dashArray:['car','lift'].includes(t.mode)?'5 6':null}).addTo(m).bindTooltip(routeHoverHTML(r,t),{sticky:true,className:'route-hover'});});r.points.forEach((key,i)=>{const p=pois[key];L.marker(p.pos,{icon:L.divIcon({className:'',html:'<div class="dotmarker" style="--route:'+r.color+'">'+(i===0?id:'·')+'</div>',iconSize:[28,28],iconAnchor:[14,14]}),title:p.name}).addTo(m).bindPopup('<b>'+esc(p.name)+'</b>'+photoPopup(key)+'<p><a target="_blank" rel="noopener" href="https://www.google.com/maps/dir/?api=1&destination='+p.pos.join(',')+'">Как добраться ↗</a></p>');});});
 stops.filter(s=>s.routes.some(id=>ids.includes(id))).forEach(s=>{bounds.push(s.pos);L.marker(s.pos,{title:s.name,icon:L.divIcon({className:'stop-icon',html:stopSymbol(s.type),iconSize:[28,28],iconAnchor:[14,14]})}).addTo(m).bindPopup('<b>'+esc(s.name)+'</b><p>'+esc(s.description||'')+'</p><a target="_blank" rel="noopener" href="https://www.google.com/maps/dir/?api=1&destination='+s.pos.join(',')+'">Маршрут в Google Maps ↗</a>');});
 if(trip.transport==='car')(tripTransfers(ids)?.legs||[]).forEach(l=>{const path=legRoad(l);bounds.push(...path);L.polyline(path,{color:'#fff',weight:8,interactive:false}).addTo(m);L.polyline(path,{className:'plan-transfer-road',color:'#b34d16',weight:4,dashArray:'10 6'}).addTo(m).bindPopup('№'+l.from+' → №'+l.to+' · '+driveKm(l.meters)+' · '+driveTime(l.seconds)+'<p><a href="'+legGoogle(l)+'" target="_blank" rel="noopener">Проверить дорогу ↗</a></p>');});
 (DATA.alerts||[]).filter(a=>(!trip.date?dateIntersects(a,''):[trip.date,addDays(trip.date,trip.days-1)].some(d=>dateIntersects(a,d)))&&mapAlertRelevant(a,ids,ids)).forEach(a=>L.marker(a.pos,{icon:L.divIcon({className:'alert-icon',html:'<span class="alert-pin">!</span>',iconSize:[34,46],iconAnchor:[17,46]}),title:a.name}).addTo(m).bindPopup(alertPopup(a)));
 if(bounds.length)m.fitBounds(bounds,{padding:[35,35],maxZoom:14});planMapObserver=new ResizeObserver(()=>{if(planOverviewMap===m){m.invalidateSize({pan:false});if(bounds.length)m.fitBounds(bounds,{padding:[35,35],maxZoom:14});}});planMapObserver.observe($('planMap'));
}
async function loadPlanWeather(el){
 const id=+el.dataset.planWeather,r=routeBy(id),date=routeDate(id)||trip.date,today=weatherDateKey(),intro='<h4>№'+id+' · '+esc(r.name)+'</h4>',season='<p><b>Осенью:</b> '+esc(r.autumn)+'</p><p>В горах возможны заморозки и снег, даже когда в долинах тепло; в октябре и ноябре световой день короче, а сезонные службы закрываются. Это сезонный ориентир, не прогноз на выбранную дату.</p>';
 if(!date||date<today||date>addDays(today,15)){el.innerHTML=intro+'<p><b>'+(!date?'Выберите дату поездки.':date<today?'Выбранная дата уже прошла.':'На '+esc(niceDate(date))+' прогноз ещё слишком ранний.')+'</b> '+(!date?'После выбора даты покажем доступный прогноз.':'')+'</p>'+season;return;}
 el.innerHTML=intro+'<p>Загружаем прогноз на '+esc(niceDate(date))+'…</p>';
 try{const url=new URL(weatherURL(weatherPoints(id)[0]));url.searchParams.set('forecast_days','16');const response=await fetch(url,{signal:AbortSignal.timeout(15000)});if(!response.ok)throw Error('weather');const data=await response.json(),d=data.daily,i=d?.time?.indexOf(date);if(i===undefined||i<0||!Number.isFinite(d.temperature_2m_max?.[i]))throw Error('no date');if(!el.isConnected)return;el.innerHTML=intro+'<p><b>'+esc(niceDate(date))+' · '+weatherCondition(d.weather_code[i])[1]+'</b><br>'+weatherNumber(d.temperature_2m_min[i])+'…'+weatherNumber(d.temperature_2m_max[i])+' °C · осадки '+weatherNumber(d.precipitation_sum[i],1)+' мм · порывы '+weatherNumber(d.wind_gusts_10m_max[i])+' км/ч</p><p>'+esc(weatherConfig(id).avoid)+'</p><small>Open-Meteo · <a href="https://creativecommons.org/licenses/by/4.0/" target="_blank" rel="noopener">CC BY 4.0</a> · '+esc(pois[weatherPoints(id)[0]].name)+'. '+(date>addDays(today,6)?'Дальний прогноз предварительный; перепроверьте за 1–3 дня.':'Проверьте снова перед выходом.')+'</small>';}
 catch{if(el.isConnected)el.innerHTML=intro+'<p>Прогноз на выбранную дату сейчас недоступен. <a target="_blank" rel="noopener" href="https://www.euskalmet.euskadi.eus/">Проверить предупреждения Euskalmet ↗</a></p>'+season;}
}

function recommendedPair(){
 const eligible=routes.filter(routeMatches);if(eligible.length<2)return eligible.map(r=>r.id);
 const pairs=[];for(let i=0;i<eligible.length;i++)for(let j=i+1;j<eligible.length;j++){
  const a=eligible[i],b=eligible[j],ab=tripTransfers([a.id,b.id]),ba=tripTransfers([b.id,a.id]);
  const reverse=(ba?.seconds??Infinity)<(ab?.seconds??Infinity);pairs.push({ids:reverse?[b.id,a.id]:[a.id,b.id],score:a.scenic+b.scenic,coastal:Number(a.id<=7)+Number(b.id<=7),drive:Math.min(ab?.seconds??Infinity,ba?.seconds??Infinity)});
 }
 pairs.sort((a,b)=>b.score-a.score||b.coastal-a.coastal||a.drive-b.drive||a.ids[0]-b.ids[0]);return pairs[0].ids;
}
function addRecommendedDay(){
 const ids=recommendedPair();if(!ids.length){toast('По выбранным фильтрам нет маршрутов. Измените условия.');return;}
 rememberPlanChange('Добавлена рекомендация по выбранным фильтрам');trip.recommended=ids;trip.itinerary=cleanIDs([...trip.itinerary,...ids]);
 ids.forEach(id=>visible.add(id));closeRouteDetail();drawList();drawMap();refreshPlanner();
 planEntryApproved=true;try{setTab('tripview');}finally{planEntryApproved=false;}
}
function recommendationNote(ids){
 const chosen=trip.recommended||[];if(!chosen.length||chosen.join(',')!==ids.join(','))return '';
 const list=chosen.map(id=>'маршрут №'+id+' ('+esc(routeBy(id).name)+' — '+esc(routeBeauty(id))+')').join(' + '),t=tripOverview(chosen),pub=trip.transport==='public',drive=pub?0:(t.drive?.seconds||0)/3600;
 const reserve=chosen.reduce((sum,id)=>sum+(configFor(id).extraMinutes||0)/60,0),upper=t.hours[1]+drive+reserve,split=chosen.length>1&&upper>8;
 return '<aside class="recommended-note"><b>Рекомендованная подборка</b><p>'+list+'</p><p>'+(chosen.length===1?((trip.recommended||[]).length===1?'По выбранным фильтрам доступен один маршрут — добавили его.':'В плане остался один из рекомендованных маршрутов.'):split?'Лучше разнести эти два маршрута на два дня: по одному треку в день. Вместе это до ≈ '+Math.ceil(upper)+' ч с резервом на отдых и местный транспорт'+(pub?', ещё без автобусных переездов и ожидания.':', включая переезд между треками.'):'Эти маршруты можно рассмотреть для одного дня: до ≈ '+Math.ceil(upper)+' ч с резервом'+(pub?', без времени автобусов и ожидания. Сначала проверьте стыковки.':'. Учитывайте световой день, погоду и часы работы подъёмников.'))+'</p><small>Выбраны самые высокие оценки зрелищности среди маршрутов по вашим фильтрам; при равенстве — прибрежные маршруты, затем более короткий автомобильный переезд. Это подборка для планирования, а не подтверждение доступности троп. Ранее добавленные маршруты сохранены.</small></aside>';
}

function routeBeauty(id){return routeBy(id).scenicReason||routeBy(id).highlights;

}
