# Ежедневная проверка Basque Hikes

Только C:/Users/visok/Documents/Codex/2026-09-08/basque-hikes, репозиторий visokihy-cyber/basque-hikes, сайт https://visokihy-cyber.github.io/basque-hikes/. Не изменять html, сайт Доломит, его репозиторий и автоматизацию.

Ежедневно в 10:00 Europe/Moscow сверять действующие ограничения и изменения на ближайшие 14 дней: тропы, дороги, тоннель San Adrián, парковки, автобусы и билеты, кухни и сезонные часы, погодные предупреждения. Фото исключены из регулярной проверки.

Источники: sources маршрутов в work/content.json, source остановок work/stops.json и предупреждений, расписания work/planner.json. Приоритет официальным сайтам парков Gorbeia, Urkiola, Urdaibai, Aizkorri-Aratz, Valderejo, Gorbeia Euskadi, Goierri Turismo, Trafikoa Euskadi, Alavabus, Bizkaibus, Lurraldebus, Euskotren и Euskalmet. Проверять дату публикации.

Отличать подтверждённое закрытие от отсутствия подтверждения открытия. Не менять дату фактической сверки без прочтения источника. При недоступности сохранять последнюю подтверждённую информацию и её дату. Не объявлять маршрут безопасным только по отсутствию сообщений. У предупреждения Nervión от июля 2025 нет подтверждённой отмены: не придумывать срок окончания.

Рестораны: Google строго выше 4.5 и Tripadvisor не ниже 4.5; проверять ресторан, не рейтинг отеля. Кафе и хижины с кухней также подходят при выполнении критериев. У Txopekua часы Google и Tripadvisor расходятся; до подтверждения оператором сохранять расхождение. Не менять ratingCheckedAt без проверки обоих рейтингов. Не смешивать часы кухни и размещения.

Погода: живой Open-Meteo на три дня для двенадцати маршрутов; Europe/Madrid, кеш с датой. Проверять API и предупреждения Euskalmet. Прогноз на дату только в доступном горизонте; климатический ориентир не является прогнозом.

OSM от 13.09.2026, пешие маршруты реконструированы по OSM/BRouter, переезды OSRM от 14.09.2026. Даты не обновлять без пересчёта. Не подменять общественный транспорт автомобильным временем: при отсутствии проверенного расчёта писать, что требуются расписание и проверка последней части пути.

Редактировать work/content.json, stops.json, planner.json, page.html, planner.js/css, flow.css. Сборка: Python work/assemble.py; node --check work/app-check.js; node work/check-basque.cjs; node work/build-route-exports.cjs; Python work/package-release.py. Python: C:/Users/visok/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe -X utf8. Не запускать одноразовые build-data.py/adapt-template.py/refine.py/enrich.py: они перезаписывают данные. Погодный код находится в page.html.

Проверить изменённые карточки, план, карту, погоду и экспорт. Записать источники и неопределённости в research/audit-YYYY-MM-DD.md. Публиковать только outputs/site в новый репозиторий; проверить публичные файлы. В отчёте указать изменения и недоступные источники. Не отправлять письма заказчикам.

14.09.2026: подборка заменена на 12 маршрутов для базы Сан-Себастьян, приоритет побережью. Старые IDs не совместимы: ключ localStorage basque-hikes-coastal12-v1. Варианты Flysch и Aizkorri имеют собственные линии, профили, экспорт. Проверять вход Gaztelugatxe, часы ворот Urgull, приливы и штормовые предупреждения, возврат Euskotren Deba — Zumaia и из Pasaia. Источники в content.json. Не запускать build-coastal-12.py / finish-coastal-ui.py при ежедневном обслуживании: это одноразовые миграции. Старый сайт Доломит не менять.
