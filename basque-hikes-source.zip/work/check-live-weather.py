import json,urllib.request,urllib.parse,time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
w=Path(__file__).resolve().parent;r=w.parent/'research';d=json.loads((w/'content.json').read_text(encoding='utf-8'));raw=json.loads((w/'routes_raw.json').read_text(encoding='utf-8'))
def run(route):
 key=route['weather']['points'][0];p=raw['pois'][key]
 url='https://api.open-meteo.com/v1/forecast?'+urllib.parse.urlencode({'latitude':p['pos'][0],'longitude':p['pos'][1],'daily':'weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,wind_gusts_10m_max,snowfall_sum','forecast_days':3,'timezone':'Europe/Madrid','wind_speed_unit':'kmh'})
 try:
  data=json.load(urllib.request.urlopen(url,timeout=20));assert len(data['daily']['time'])==3
  (r/('weather-'+key+'.json')).write_text(json.dumps({'fetchedAt':round(time.time()*1000),'url':url,'data':data}));return route['id'],data['daily']['time'],data['elevation']
 except Exception as e:return route['id'],str(e)
print(list(ThreadPoolExecutor(3).map(run,d['routes'])))
