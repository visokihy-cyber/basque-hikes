const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync('outputs/basque-hikes-autumn-2026.html','utf8');
const data=JSON.parse(html.match(/<script id="atlas-data" type="application\/json">(.*?)<\/script>/s)[1]);
const app=fs.readFileSync('work/page.html','utf8');
const ctx=vm.createContext({pois:data.pois});
vm.runInContext(app.slice(app.indexOf('const xml='),app.indexOf('function saveTrack(')),ctx);
fs.mkdirSync('outputs/route-tracks',{recursive:true});
for(const r of data.routes){
 const ts=r.tracks.map(id=>data.tracks.find(t=>t.id===id)).filter(t=>!['car','lift'].includes(t.mode));
 assert(ts.length>0);
 for(const fmt of ['kml','gpx']){
  const result=ctx.exportText(ts,r,fmt,true);
  fs.writeFileSync(`outputs/route-tracks/${String(r.id).padStart(2,'0')}-route.${fmt}`,result);
 }
}
for(const [id,variants] of Object.entries(data.planner.variants)){
 const base=data.routes.find(r=>r.id===Number(id)),r={...base,...variants.short};
 const ts=r.tracks.map(id=>data.tracks.find(t=>t.id===id)).filter(t=>!['car','lift'].includes(t.mode));
 for(const fmt of ['kml','gpx'])fs.writeFileSync(`outputs/route-tracks/${String(id).padStart(2,'0')}-route-short.${fmt}`,ctx.exportText(ts,r,fmt,true));
}
console.log('Exported 8 complete routes, each in KML and GPX');
