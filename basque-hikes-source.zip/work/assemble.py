import json,pathlib,math,re,base64,shutil,html as html_tools
w=pathlib.Path('work'); out=pathlib.Path('outputs');out.mkdir(exist_ok=True)
d=json.loads((w/'routes_raw.json').read_text(encoding='utf-8'));d.update(json.loads((w/'content.json').read_text(encoding='utf-8')))
elevations=json.loads((w/'elevations.json').read_text(encoding='utf-8'))
for t in d['tracks']:
 t['elevation']=elevations.get(t['id'])
for r in d['routes']:
 assert all(k in d['pois'] for k in r['points']),r['name']
 assert all(any(t['id']==k for t in d['tracks']) for k in r['tracks']),r['name']
for t in d['tracks']:
 assert len(t['points'])>1
 assert all(42.7<p[0]<43.6 and -3.6<p[1]<-1.5 for p in t['points'])
d['photos']=json.loads((w/'photos.json').read_text(encoding='utf-8'))
d['stops']=json.loads((w/'stops.json').read_text(encoding='utf-8'))
d['driving']=json.loads((w/'driving.json').read_text(encoding='utf-8'))
d['offline']=json.loads((w/'offline.json').read_text(encoding='utf-8'))
d['planner']=json.loads((w/'planner.json').read_text(encoding='utf-8'))
h=(w/'page.html').read_text(encoding='utf-8')
h=h.replace('/*PLANNER_JS*/',(w/'planner.js').read_text(encoding='utf-8')).replace('/*PLANNER_CSS*/',(w/'planner.css').read_text(encoding='utf-8')+'\n'+(w/'flow.css').read_text(encoding='utf-8'))
h=h.replace("function updateTrackSelect(){let list=tracks.filter(t=>t.route===selected&&!hiddenTracks.has(t.id));", "function updateTrackSelect(){let list=tracks.filter(t=>t.route===selected&&visibleTrack(t));")
h=h.replace("function drawMap(){lineLayer.clearLayers();", "function drawMap(){if(traveller&&(!trackBy(activeTrack)||!visibleTrack(trackBy(activeTrack)))){map.removeLayer(traveller);traveller=null;}lineLayer.clearLayers();")
h=h.replace("pause();drawMap();});}","pause();drawMap();updateTrackSelect();});}")
h=h.replace("pause();drawMap()});$('basemap')", "pause();drawMap();updateTrackSelect()});$('basemap')")
h=h.replace("if(zoom)fitRoute(id);}","if(zoom){fitRoute(id);if(innerWidth<721)$('mapview').scrollIntoView();}}")
h=h.replace('/*LEAFLET_CSS*/',(w/'leaflet.css').read_text(encoding='utf-8')).replace('/*LEAFLET_JS*/',(w/'leaflet.js').read_text(encoding='utf-8'))
template=h
h=h.replace('/*ATLAS_DATA*/',json.dumps(d,ensure_ascii=False,separators=(',',':')).replace('</','<\\/'))
(out/'basque-hikes-autumn-2026.html').write_text(h,encoding='utf-8')
(w/'app-check.js').write_text(h.rsplit('<script>',1)[1].split('</script>')[0],encoding='utf-8')
print('Built',len(h),'characters;',len(d['routes']),'routes;',len(d['tracks']),'tracks;',len(d['pois']),'points')
site=out/'site';site.mkdir(exist_ok=True)
online=json.loads(json.dumps(d));online['offline']={**{k:v for k,v in d['offline'].items() if k not in ['areas','roads','labels']},'areas':[],'roads':[],'labels':[]}
for photo in online['photos']:
 name='photo-'+photo['id']+'.webp'
 (site/name).write_bytes(base64.b64decode(photo['src'].split(',',1)[1]));photo['src']=name
shutil.copyfile(w/'offline.json',site/'offline.json')
web=template.replace('/*ATLAS_DATA*/',json.dumps(online,ensure_ascii=False,separators=(',',':')).replace('</','<\\/'))
(site/'index.html').write_text(web,encoding='utf-8')
shutil.copyfile(w/'custom-map.html',site/'custom-map.html')
shutil.copyfile(site/online['photos'][0]['src'],site/'share-cover.webp')
for route in d['routes']:
 rid=route['id'];url=f'https://visokihy-cyber.github.io/basque-hikes/route-{rid:02d}.html';title=html_tools.escape(route['name']+' · Страна Басков на выходной',quote=True);description=html_tools.escape(route['intro']+' '+route['distance']+' · '+route['time']+'.',quote=True)
 page=web.replace('<body>',f'<body data-route="{rid}">').replace('<title>Страна Басков · горы на выходной</title>','<title>'+title+'</title>')
 page=re.sub(r'(<meta name="description" content=")[^"]*',lambda m:m[1]+description,page,count=1)
 page=re.sub(r'(<meta property="og:title" content=")[^"]*',lambda m:m[1]+title,page,count=1)
 page=re.sub(r'(<meta property="og:description" content=")[^"]*',lambda m:m[1]+description,page,count=1)
 page=page.replace('<meta property="og:url" content="https://visokihy-cyber.github.io/basque-hikes/">','<meta property="og:url" content="'+url+'">').replace('<link rel="canonical" href="https://visokihy-cyber.github.io/basque-hikes/">','<link rel="canonical" href="'+url+'">')
 fallback='<noscript><article><h1>'+title+'</h1><p>'+description+'</p><p>'+html_tools.escape(route['difficulty'])+'</p><a href="./">Все маршруты</a></article></noscript>'
 page=page.replace('<body data-route="'+str(rid)+'">','<body data-route="'+str(rid)+'">'+fallback)
 (site/f'route-{rid:02d}.html').write_text(page,encoding='utf-8')
(site/'sitemap.xml').write_text('<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+''.join('<url><loc>'+u+'</loc></url>' for u in ['https://visokihy-cyber.github.io/basque-hikes/','https://visokihy-cyber.github.io/basque-hikes/custom-map.html']+[f'https://visokihy-cyber.github.io/basque-hikes/route-{r["id"]:02d}.html' for r in d['routes']])+'</urlset>',encoding='utf-8')
(site/'.nojekyll').touch()
print('Web HTML:',(site/'index.html').stat().st_size,'bytes; photos and offline geography loaded separately; 8 route pages')
