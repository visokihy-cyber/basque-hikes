from pathlib import Path
import json,zipfile,shutil,re,hashlib
root=Path.cwd();site=root/'outputs/site';w=root/'work'
readme='''# Basque Hikes — Страна Басков на выходной

Сайт: https://visokihy-cyber.github.io/basque-hikes/

12 маршрутов из Сан-Себастьяна: побережье и самые выразительные горные прогулки. У Flysch и Aizkorri есть короткие варианты с отдельной геометрией и экспортом.

## Офлайн
Скачайте basque-hikes-offline.zip, распакуйте и откройте basque-hikes-autumn-2026.html в браузере. Выберите «Офлайн · Страна Басков». Фотографии, рельеф маршрутов, география OSM и рассчитанные автопереезды включены. Прогноз и внешние ссылки требуют интернета. В папке route-tracks — полный GPX и KML каждого маршрута. HTML-план можно сохранить и распечатать через сайт.

## Данные и пределы точности
География OpenStreetMap / ODbL от 13.09.2026. Пешие линии реконструированы по OSM/BRouter; это не обследование маршрута на местности. Высоты приближённые. Переезды OSRM от 14.09.2026 не учитывают текущие пробки, закрытия и остановки. Не выдаём автомобильное время за общественный транспорт: проверяйте ссылки операторов и последнюю часть пути.

Часы кухни и доступность парковок, не подтверждённые оператором, подписаны как неопределённые. Для Txopekua Google 4.7 и Tripadvisor 4.6 проверены 15.09.2026; расписания источников расходятся. Для других проверенных заведений оба порога не подтверждены. Отсутствие предупреждения не означает подтверждённое открытие тропы. Линейные прибрежные тропы требуют отдельного возвращения к машине.

Фото Wikimedia Commons: реальные изображения, авторы, оригиналы и лицензии указаны в карточках. Перераспространение — по лицензии каждого файла. OpenTopoMap требует интернет и указанную атрибуцию. Leaflet: BSD-2-Clause. Погода Open-Meteo: CC BY 4.0.

## Исходники
basque-hikes-source.zip содержит шаблоны, данные, сборку, проверку и инструкцию обслуживания. Python work/assemble.py; node work/check-basque.cjs; node work/build-route-exports.cjs; Python work/package-release.py. Одноразовые генераторы не нужны для обслуживания.

Проект полностью отдельный от сайта Доломит.
'''
(site/'README.md').write_text(readme,encoding='utf-8')
for p in (root/'outputs/route-tracks').glob('*'):shutil.copyfile(p,site/p.name)
photos=json.loads((w/'photos.json').read_text(encoding='utf-8'))
allowed={'photo-'+p['id']+'.webp' for p in photos}
for p in site.glob('photo-*.webp'):
 if p.name not in allowed:
  assert p.resolve().parent==site.resolve();p.unlink()
with zipfile.ZipFile(site/'basque-hikes-offline.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 z.write(root/'outputs/basque-hikes-autumn-2026.html','basque-hikes-autumn-2026.html')
 z.writestr('README.md',readme)
 for p in (root/'outputs/route-tracks').glob('*'):z.write(p,'route-tracks/'+p.name)
names=['page.html','planner.js','planner.css','flow.css','leaflet.css','leaflet.js','content.json','routes_raw.json','elevations.json','photos.json','stops.json','driving.json','offline.json','planner.json','custom-map.html','assemble.py','build-route-exports.cjs','check-basque.cjs','check-live-weather.py','package-release.py','maintenance.md']
with zipfile.ZipFile(site/'basque-hikes-source.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 z.writestr('README.md',readme)
 for name in names:z.write(w/name,'work/'+name)
manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in site.iterdir() if p.is_file()}
(root/'research/release-sha256.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
assert all(p.stat().st_size<25*1024*1024 for p in site.iterdir() if p.is_file())
print(len(manifest),'files;',sum(p.stat().st_size for p in site.iterdir() if p.is_file())//1024//1024,'MiB; archives',[(p.name,p.stat().st_size) for p in site.glob('*.zip')])
