const fs=require('fs'),vm=require('vm'),assert=require('assert');
const page=fs.readFileSync('outputs/site/index.html','utf8'),source=fs.readFileSync('work/page.html','utf8');
const DATA=JSON.parse(page.match(/<script id="atlas-data" type="application\/json">(.*?)<\/script>/s)[1]);
const url=new URL('https://visokihy-cyber.github.io/basque-hikes/'),ctx=vm.createContext({DATA,routes:DATA.routes,tracks:DATA.tracks,stops:DATA.stops,pois:DATA.pois,location:url,document:{baseURI:url.href,body:{dataset:{}}},URL,URLSearchParams,Intl,Date,localStorage:{getItem:()=>null},weatherDateKey:(d=new Date())=>new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Madrid',year:'numeric',month:'2-digit',day:'2-digit'}).format(d),alertInWindow:()=>true});
vm.runInContext('const routeBy=id=>routes.find(r=>r.id===Number(id)),trackBy=id=>tracks.find(t=>t.id===id);let visible=new Set(),selected=null,browseRegion="all",browseEffort="all";',ctx);
for(const [a,b] of [['function calculateTransfers(','function driveKm('],['function decodeRoad(','function legRoad(']])vm.runInContext(source.slice(source.indexOf(a),source.indexOf(b)),ctx);
vm.runInContext('function legRoad(l){const r=DATA.driving.roads[l.start+"-"+l.end];return r?[...decodeRoad(r.geometry),...(r.access||[])]:[];}',ctx);
vm.runInContext(fs.readFileSync('work/planner.js','utf8'),ctx);
assert.equal(DATA.routes.length,12);assert.equal(DATA.tracks.length,14);assert.equal(Object.keys(DATA.driving.roads).length,132);
assert(ctx.validTripDate('2026-09-30'));assert(!ctx.validTripDate('2026-09-31'));
assert.deepEqual([...ctx.cleanIDs([1,1,'2',99,-1])],[1,2]);
assert.equal(ctx.normalizePlan({itinerary:[1,2,3]}).itinerary.length,3);
assert.equal(ctx.normalizePlan({itinerary:[1,2,3],recommended:[1,2]}).recommended.length,0);
assert.equal(ctx.normalizePlan({itinerary:[1,2],recommended:[1,2]}).recommended.length,2);
vm.runInContext('trip=normalizePlan({exposure:"no"});',ctx);
assert(ctx.recommendedRoutes().every(r=>!ctx.configFor(r.id).exposure));
vm.runInContext('trip=normalizePlan({itinerary:[1,2],date:"2026-09-20"});visible=new Set([3]);',ctx);
assert.equal(ctx.routeDate(2),'2026-09-21');assert.equal(ctx.planURL().searchParams.get('plan'),'1,2');assert.equal(ctx.planURL().searchParams.get('routes'),'3');
ctx.location=ctx.planURL();assert.deepEqual([...ctx.readPlan().itinerary],[1,2]);
for(const a of DATA.routes)for(const b of DATA.routes){if(a.id===b.id)continue;const t=ctx.tripTransfers([a.id,b.id]);assert.equal(t.legs.length,1);const road=ctx.legRoad(t.legs[0]);assert(road.length>2);assert(road.every(p=>p[0]>42&&p[0]<44&&p[1]>-4&&p[1]<-1));}
assert(ctx.routeAlerts([4],'2026-09-20').length===1);assert(ctx.routeAlerts([1],'2026-09-20').length===0);
for(const route of DATA.routes){assert(ctx.parkingFor(route.id));assert(route.weather.points.every(k=>DATA.pois[k]));assert(new Set(DATA.photos.filter(p=>p.tracks.includes(route.tracks[0])).map(p=>p.point)).size>=3,route.name+' needs three photo points');for(const key of route.tracks){const t=DATA.tracks.find(t=>t.id===key);assert(t.points.length>20);assert(t.km>0);assert(t.elevation);}}
for(const p of DATA.photos){assert(fs.existsSync('outputs/site/'+p.src));assert(p.license&&p.author&&p.source);}
for(const s of DATA.stops.filter(s=>s.type==='food')){assert(s.google>4.5&&s.ta>=4.5);assert(s.taUrl&&s.ratingCheckedAt);}
assert(!/dolomites|Tre Cime|Compatsch|Auronzo|Europe\/Rome/.test(page));
assert(fs.statSync('outputs/site/offline.json').size<25000000);
console.log('PASS: 12 routes; 132 directed transfers; independent map/plan serialization; exposure filter; alerts; photos; food thresholds; namespaces');

// Navigation regression: display, driving and route-start links must agree on parking coordinates.
for(const [a,b] of [['function stopMapUrl(','function stopCard('],['function hrefStart(','function ']]){
 const start=source.indexOf(a);const end=b==='function '?source.indexOf(b,start+a.length):source.indexOf(b,start);vm.runInContext(source.slice(start,end),ctx);
}
ctx.esc=s=>String(s);
for(const r of DATA.routes){
 const park=ctx.parkingFor(r.id),expected=park.pos.join(',');
 assert.equal(new URL(ctx.stopMapUrl(park)).searchParams.get('query'),expected,r.name);
 assert.equal(new URL(ctx.stopNav(park)).searchParams.get('destination'),expected,r.name);
 assert.equal(new URL(ctx.hrefStart(r,'')).searchParams.get('destination'),expected,r.name);
 const html=ctx.parkingStartHTML(park);assert(html.includes(park.pos[0].toFixed(6)));assert(html.includes('Начало пешего трека')||html.includes('начинается у этой парковки'));
}
assert.equal(new URL(ctx.stopMapUrl(DATA.stops.find(s=>s.id==='txopekua'))).searchParams.get('query_place_id'),'ChIJ-2EXmMUpUA0Rq9yadNgB7-A');
console.log('PASS: all 12 parking destinations agree; separate walking starts labelled; restaurant Place ID preserved');
